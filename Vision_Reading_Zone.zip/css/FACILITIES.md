FACILITIES
-Peaceful Study Environment
-Fully AC
-Free Hi- Speed WiFi
-Comfortable Timing
-Newspaper & Articles


#ff7236 --orange color





<!-- Start: Features -->
		<section class="features">
			<div class="container">
				<ul>
					<li class="bg-yellow">
						<div class="feature-box">
							<i class="yellow"></i>
							<h3>Books</h3>
							<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dolor turpis, pulvinar varius dui id, convallis iaculis eros.</p> -->
							<a class="yellow" href="#"> View Selection <i class="fa fa-long-arrow-right"></i> </a>
						</div>
					</li>
					<li class="bg-light-green">
						<div class="feature-box">
							<i class="light-green"></i>
							<h3>eBooks</h3>
							<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dolor turpis, pulvinar varius dui id, convallis iaculis eros.</p> -->
							<a class="light-green" href="#"> View Selection <i class="fa fa-long-arrow-right"></i> </a>
						</div>
					</li>
					<li class="bg-blue">
						<div class="feature-box">
							<i class="blue"></i>
							<h3>DVDs</h3>
							<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dolor turpis, pulvinar varius dui id, convallis iaculis eros.</p> -->
							<a class="blue" href="#"> View Selection <i class="fa fa-long-arrow-right"></i> </a>
						</div>
					</li>
					<li class="bg-red">
						<div class="feature-box">
							<i class="red"></i>
							<h3>Magazines</h3>
							<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dolor turpis, pulvinar varius dui id, convallis iaculis eros.</p> -->
							<a class="red" href="#"> View Selection <i class="fa fa-long-arrow-right"></i> </a>
						</div>
					</li>
					<li class="bg-violet">
						<div class="feature-box">
							<i class="violet"></i>
							<h3>Audio</h3>
							<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dolor turpis, pulvinar varius dui id, convallis iaculis eros.</p> -->
							<a class="violet" href="#"> View Selection <i class="fa fa-long-arrow-right"></i> </a>
						</div>
					</li>
					<li class="bg-green">
						<div class="feature-box">
							<i class="green"></i>
							<h3>eAudio</h3>
							<!-- <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dolor turpis, pulvinar varius dui id, convallis iaculis eros.</p> -->
							<a class="green" href="#"> View Selection <i class="fa fa-long-arrow-right"></i> </a>
						</div>
					</li>
				</ul>
			</div>
		</section>
		<!-- End: Features -->



        <!-- Start: Our Community Section -->
		<section class="community-testimonial">
			<div class="container">
				<div class="text-center">
					<h2 class="section-title">Words From our Community</h2>
					<span class="underline center"></span>
					<p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
				</div>
				<div class="owl-carousel">
					<div class="single-testimonial-box">
						<div class="top-portion">
							<img src="images/testimonial-image-01.jpg" alt="Testimonial Image" />
							<div class="user-comment">
								<div class="arrow-left"></div>
								<blockquote cite="#">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna magna,
									rhoncus eget commodo et, dignissim non nulla. Sed sit amet vestibulum ex. Donec
									dolor
									velit
								</blockquote>
							</div>
							<div class="clear"></div>
						</div>
						<div class="bottom-portion">
							<a href="#" class="author"> Adrey Pachai <small>(Student )</small> </a>
							<div class="social-share-links">
								<ul>
									<li>
										<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
									</li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="single-testimonial-box">
						<div class="top-portion">
							<img src="images/testimonial-image-02.jpg" alt="Testimonial Image" />
							<div class="user-comment">
								<div class="arrow-left"></div>
								<blockquote cite="#">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna magna,
									rhoncus eget commodo et, dignissim non nulla. Sed sit amet vestibulum ex. Donec
									dolor
									velit
								</blockquote>
							</div>
							<div class="clear"></div>
						</div>
						<div class="bottom-portion">
							<a href="#" class="author"> Maria B <small>(Student )</small> </a>
							<div class="social-share-links">
								<ul>
									<li>
										<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
									</li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="single-testimonial-box">
						<div class="top-portion">
							<img src="images/testimonial-image-01.jpg" alt="Testimonial Image" />
							<div class="user-comment">
								<div class="arrow-left"></div>
								<blockquote cite="#">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna magna,
									rhoncus eget commodo et, dignissim non nulla. Sed sit amet vestibulum ex. Donec
									dolor
									velit
								</blockquote>
							</div>
							<div class="clear"></div>
						</div>
						<div class="bottom-portion">
							<a href="#" class="author"> Adrey Pachai <small>(Student )</small> </a>
							<div class="social-share-links">
								<ul>
									<li>
										<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
									</li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="single-testimonial-box">
						<div class="top-portion">
							<img src="images/testimonial-image-02.jpg" alt="Testimonial Image" />
							<div class="user-comment">
								<div class="arrow-left"></div>
								<blockquote cite="#">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna magna,
									rhoncus eget commodo et, dignissim non nulla. Sed sit amet vestibulum ex. Donec
									dolor
									velit
								</blockquote>
							</div>
							<div class="clear"></div>
						</div>
						<div class="bottom-portion">
							<a href="#" class="author"> Maria B <small>(Student )</small> </a>
							<div class="social-share-links">
								<ul>
									<li>
										<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
									</li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="single-testimonial-box">
						<div class="top-portion">
							<img src="images/testimonial-image-01.jpg" alt="Testimonial Image" />
							<div class="user-comment">
								<div class="arrow-left"></div>
								<blockquote cite="#">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna magna,
									rhoncus eget commodo et, dignissim non nulla. Sed sit amet vestibulum ex. Donec
									dolor
									velit
								</blockquote>
							</div>
							<div class="clear"></div>
						</div>
						<div class="bottom-portion">
							<a href="#" class="author"> Adrey Pachai <small>(Student )</small> </a>
							<div class="social-share-links">
								<ul>
									<li>
										<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
									</li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="single-testimonial-box">
						<div class="top-portion">
							<img src="images/testimonial-image-02.jpg" alt="Testimonial Image" />
							<div class="user-comment">
								<div class="arrow-left"></div>
								<blockquote cite="#">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna magna,
									rhoncus eget commodo et, dignissim non nulla. Sed sit amet vestibulum ex. Donec
									dolor
									velit
								</blockquote>
							</div>
							<div class="clear"></div>
						</div>
						<div class="bottom-portion">
							<a href="#" class="author"> Maria B <small>(Student )</small> </a>
							<div class="social-share-links">
								<ul>
									<li>
										<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
									</li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="single-testimonial-box">
						<div class="top-portion">
							<img src="images/testimonial-image-01.jpg" alt="Testimonial Image" />
							<div class="user-comment">
								<div class="arrow-left"></div>
								<blockquote cite="#">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna magna,
									rhoncus eget commodo et, dignissim non nulla. Sed sit amet vestibulum ex. Donec
									dolor
									velit
								</blockquote>
							</div>
							<div class="clear"></div>
						</div>
						<div class="bottom-portion">
							<a href="#" class="author"> Adrey Pachai <small>(Student )</small> </a>
							<div class="social-share-links">
								<ul>
									<li>
										<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
									</li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="single-testimonial-box">
						<div class="top-portion">
							<img src="images/testimonial-image-02.jpg" alt="Testimonial Image" />
							<div class="user-comment">
								<div class="arrow-left"></div>
								<blockquote cite="#">
									Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent urna magna,
									rhoncus eget commodo et, dignissim non nulla. Sed sit amet vestibulum ex. Donec
									dolor
									velit
								</blockquote>
							</div>
							<div class="clear"></div>
						</div>
						<div class="bottom-portion">
							<a href="#" class="author"> Maria B <small>(Student )</small> </a>
							<div class="social-share-links">
								<ul>
									<li>
										<a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-skype" aria-hidden="true"></i></a>
									</li>
									<li>
										<a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
									</li>
								</ul>
							</div>
							<div class="clearfix"></div>
						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</section>
		<!-- End: Our Community Section -->




        <!-- Start: Newsletter -->
			<section>
				<div class="container">
					<div class="row">
						<div class="col-md-8 col-md-offset-2">
							<div class="center-content">
								<h2 class="section-title">Subscribe to our Newsletters</h2>
								<span class="underline center"></span>
								<p class="lead">The standard chunk of Lorem Ipsum used since the 1500s is reproduced
									below for those interested.</p>
							</div>
							<div class="form-group">
								<input class="form-control" placeholder="Enter your Email!" id="newsletter"
									name="newsletter" type="email" />
								<input class="form-control" value="Subscribe" type="submit" />
							</div>
						</div>
					</div>
				</div>
			</section>
			<!-- End: Newsletter -->




            	
		<!-- <section class="news-events newsletter social-network section-padding banner"> -->
			<!-- Start: Social Network -->
			<div class="container">
					<div class="center-content">
						<h2 class="section-title">Follow Us</h2>
						<span class="underline center"></span>
						<p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
				
					</div>
					<div class="row">
				<div class="col-md-4"> </div>


					<div class="col-md-4"> 
					<ul>
						<li>
							<a class="facebook" href="#" target="_blank">
								<span>
									<i class="fab fa-facebook-f"></i>
								</span>
							</a>
						</li>
						<li>
							<a class="twitter" href="#" target="_blank">
								<span>
									<i class="fab fa-twitter"></i>
								</span>
							</a>
						</li>
						<li>
							<a class="instagram" href="#" target="_blank">
								<span>
									<i class="fab fa-instagram"></i>
								</span>
							</a>
						</li>
						
						
						<li>
							<a class="youtube" href="#" target="_blank">
								<span>
								<i class="fab fa-youtube"></i>
								</span>
							</a>
						</li>
					</ul>
					</div>
					<div class="col-md-4"> </div>
					</div>
				
			</div>
			<!-- End: Social Network -->
		<!-- </section> -->